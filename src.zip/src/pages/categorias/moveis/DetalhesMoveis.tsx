import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getItemById, updateItem, Item } from "../../../services/ItemService";

function EditarMovel() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Estados para cada campo editável
  const [descricao, setDescricao] = useState("");
  const [dataCadastro, setDataCadastro] = useState("");
  const [quantidade, setQuantidade] = useState<number>(1);
  const [valor, setValor] = useState<number>(0);
  const [caminhao, setCaminhao] = useState("");
  const [categoria, setCategoria] = useState("MOVEIS"); // fixo e padronizado
  const [estadoConservacao, setEstadoConservacao] = useState("");
  const [situacao, setSituacao] = useState("");
  const [anexo, setAnexo] = useState<string>(""); // Pode armazenar URL ou referência atual ao arquivo
  const [newFile, setNewFile] = useState<File | null>(null); // Caso o usuário selecione um novo arquivo

  useEffect(() => {
    async function fetchItem() {
      if (id) {
        try {
          const item: Item = await getItemById(Number(id));
          setDescricao(item.descricao);
          setDataCadastro(item.data_cadastro ?? "");
          setQuantidade(item.quantidade);
          setValor(item.valor);
          setCaminhao(item.caminhao);
          setCategoria(item.categoria); // se o backend retornar "MOVEIS", ficará padronizado
          setEstadoConservacao(item.estadoConservacao);
          setSituacao(item.situacao);
          if (item.anexo) {
            setAnexo(item.anexo);
          }
        } catch (error) {
          console.error("Erro ao buscar o móvel:", error);
          alert("Erro ao buscar o móvel. Tente novamente mais tarde.");
        }
      }
    }
    fetchItem();
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Prepara o objeto atualizado; note que, para atualizações que não envolvem upload,
    // o updateItem espera um objeto JSON do tipo Item.
    const updatedItem: Item = {
      id: Number(id),
      descricao,
      data_cadastro: dataCadastro,
      quantidade,
      valor,
      caminhao,
      categoria,
      estadoConservacao,
      situacao,
      // Se não houver novo arquivo, a propriedade anexo permanece inalterada.
      anexo: anexo,
    };

    try {
      // Se você precisar enviar arquivo via atualização, poderá adaptar para enviar FormData.
      // Neste exemplo, assumimos que updateItem envia um objeto JSON.
      await updateItem(Number(id), updatedItem);
      alert("Móvel atualizado com sucesso!");
      navigate("/categorias/moveis");
    } catch (error) {
      console.error("Erro ao atualizar o móvel:", error);
      alert("Erro ao atualizar o móvel. Tente novamente.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    if (e.target.files.length > 0) {
      setNewFile(e.target.files[0]);
      // Em uma implementação mais avançada, você poderá fazer o upload do arquivo via FormData
      // e atualizar a propriedade 'anexo'. Neste exemplo, mantemos a lógica simples.
    }
  };

  const handleCancel = () => {
    navigate("/categorias/moveis");
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Editar Móvel</h1>
      <div className="form-container">
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="grid grid-cols-2 gap-4">
            <div className="form-group">
              <label className="form-label">Descrição</label>
              <input
                type="text"
                className="form-input"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Data de Cadastro</label>
              <input
                type="date"
                className="form-input"
                value={dataCadastro}
                onChange={(e) => setDataCadastro(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Quantidade</label>
              <input
                type="number"
                className="form-input"
                value={quantidade}
                onChange={(e) => setQuantidade(Number(e.target.value))}
                min="1"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Valor (R$)</label>
              <input
                type="number"
                step="0.01"
                className="form-input"
                value={valor}
                onChange={(e) => setValor(Number(e.target.value))}
                min="0"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Caminhão</label>
              <input
                type="text"
                className="form-input"
                value={caminhao}
                onChange={(e) => setCaminhao(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Categoria</label>
              <input
                type="text"
                className="form-input"
                value={categoria}
                disabled
              />
            </div>

            <div className="form-group">
              <label className="form-label">Estado de Conservação</label>
              <select
                className="form-select"
                value={estadoConservacao}
                onChange={(e) => setEstadoConservacao(e.target.value)}
                required
              >
                <option value="">Selecione</option>
                <option value="Novo">Novo</option>
                <option value="Seminovo">Seminovo</option>
                <option value="Usado em bom estado">Usado em bom estado</option>
                <option value="Usado com marcas de uso">Usado com marcas de uso</option>
                <option value="Precisa de reparos">Precisa de reparos</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Situação</label>
              <select
                className="form-select"
                value={situacao}
                onChange={(e) => setSituacao(e.target.value)}
                required
              >
                <option value="">Selecione</option>
                <option value="Disponível">Disponível</option>
                <option value="Reservado">Reservado</option>
                <option value="Vendido">Vendido</option>
                <option value="Doado">Doado</option>
              </select>
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Anexo (Foto)</label>
              <input
                type="file"
                className="form-input"
                onChange={handleFileChange}
                accept="image/*"
              />
              {newFile === null && (
                <p className="text-sm text-gray-600 mt-1">
                  Nenhum arquivo selecionado. Deixe em branco para manter o anexo atual.
                </p>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <button
              type="button"
              className="form-button secondary"
              onClick={handleCancel}
            >
              Cancelar
            </button>
            <button type="submit" className="form-button success">
              Salvar Alterações
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default EditarMovel;
