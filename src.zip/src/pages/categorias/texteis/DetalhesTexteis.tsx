import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { ArrowLeft, Edit } from "lucide-react"

// Simulação de dados para têxteis
const mockTexteis = [
  {
    id: 1,
    descricao: "Camisetas Infantis",
    data_cadastro: "2023-05-10",
    quantidade: 20,
    valor: 150.0,
    caminhao: "Caminhão 01",
    categoria: "Têxteis",
    estadoConservacao: "Novo",
    situacao: "Disponível",
    anexo: null,
  },
  {
    id: 2,
    descricao: "Cobertores",
    data_cadastro: "2023-06-15",
    quantidade: 10,
    valor: 200.0,
    caminhao: "Caminhão 02",
    categoria: "Têxteis",
    estadoConservacao: "Novo",
    situacao: "Disponível",
    anexo: null,
  },
  {
    id: 3,
    descricao: "Jaquetas",
    data_cadastro: "2023-07-05",
    quantidade: 5,
    valor: 175.0,
    caminhao: "Caminhão 01",
    categoria: "Têxteis",
    estadoConservacao: "Seminovo",
    situacao: "Reservado",
    anexo: null,
  },
]

function DetalhesTextil() {
  const { id } = useParams<{ id: string }>()
  const [item, setItem] = useState<any>(null)
  const navigate = useNavigate()

  useEffect(() => {
    // Simulando busca na API
    const textil = mockTexteis.find((t) => t.id === Number(id))
    setItem(textil)
  }, [id])

  const handleVoltar = () => {
    navigate("/categorias/textil")
  }

  const handleEditar = () => {
    navigate(`/categorias/textil/editar/${id}`)
  }

  if (!item) return <p>Carregando...</p>

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary">Detalhes do Têxtil</h1>
        <div className="flex gap-2">
          <button className="form-button secondary flex items-center gap-2" onClick={handleVoltar}>
            <ArrowLeft size={18} />
            Voltar
          </button>
          <button className="form-button flex items-center gap-2" onClick={handleEditar}>
            <Edit size={18} />
            Editar
          </button>
        </div>
      </div>

      <div className="card">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="mb-2">
              <strong>ID:</strong> {item.id}
            </p>
            <p className="mb-2">
              <strong>Descrição:</strong> {item.descricao}
            </p>
            <p className="mb-2">
              <strong>Data Cadastro:</strong> {item.data_cadastro}
            </p>
            <p className="mb-2">
              <strong>Quantidade:</strong> {item.quantidade}
            </p>
            <p className="mb-2">
              <strong>Valor:</strong> R$ {item.valor.toFixed(2)}
            </p>
          </div>
          <div>
            <p className="mb-2">
              <strong>Caminhão:</strong> {item.caminhao}
            </p>
            <p className="mb-2">
              <strong>Categoria:</strong> {item.categoria}
            </p>
            <p className="mb-2">
              <strong>Estado de Conservação:</strong> {item.estadoConservacao}
            </p>
            <p className="mb-2">
              <strong>Situação:</strong> {item.situacao}
            </p>
            <p className="mb-2">
              <strong>Anexo:</strong>{" "}
              {item.anexo ? (
                <a href={item.anexo} target="_blank" rel="noopener noreferrer" className="text-primary">
                  Ver Anexo
                </a>
              ) : (
                "Sem anexo"
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DetalhesTextil
