import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { Plus, Edit, Eye, Trash2 } from "lucide-react"

// Simulação de dados para têxteis
const mockTexteis = [
  {
    id: 1,
    descricao: "Camisetas Infantis",
    data_cadastro: "2023-05-10",
    quantidade: 20,
    valor: 150.0,
    caminhao: "Caminhão 01",
    categoria: "Têxteis",
    estadoConservacao: "Novo",
    situacao: "Disponível",
    anexo: null,
  },
  {
    id: 2,
    descricao: "Cobertores",
    data_cadastro: "2023-06-15",
    quantidade: 10,
    valor: 200.0,
    caminhao: "Caminhão 02",
    categoria: "Têxteis",
    estadoConservacao: "Novo",
    situacao: "Disponível",
    anexo: null,
  },
  {
    id: 3,
    descricao: "Jaquetas",
    data_cadastro: "2023-07-05",
    quantidade: 5,
    valor: 175.0,
    caminhao: "Caminhão 01",
    categoria: "Têxteis",
    estadoConservacao: "Seminovo",
    situacao: "Reservado",
    anexo: null,
  },
]

function Texteis() {
  const [texteis, setTexteis] = useState<any[]>([])
  const navigate = useNavigate()

  useEffect(() => {
    // Simulando uma chamada de API
    setTexteis(mockTexteis)
  }, [])

  const handleNovoCadastro = () => {
    navigate("/categorias/textil/novo")
  }

  const handleEditar = (id: number) => {
    navigate(`/categorias/textil/editar/${id}`)
  }

  const handleDetalhes = (id: number) => {
    navigate(`/categorias/textil/detalhes/${id}`)
  }

  const handleExcluir = (id: number) => {
    if (confirm("Tem certeza que deseja excluir este item?")) {
      // Simulando exclusão
      setTexteis(texteis.filter((item) => item.id !== id))
      alert("Item excluído com sucesso!")
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary">Lista de Têxteis</h1>
        <button className="form-button success flex items-center gap-2" onClick={handleNovoCadastro}>
          <Plus size={18} />
          Novo Cadastro
        </button>
      </div>

      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Descrição</th>
              <th>Data Cadastro</th>
              <th>Quantidade</th>
              <th>Valor</th>
              <th>Caminhão</th>
              <th>Estado de Conservação</th>
              <th>Situação</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {texteis.length > 0 ? (
              texteis.map((item) => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.descricao}</td>
                  <td>{item.data_cadastro}</td>
                  <td>{item.quantidade}</td>
                  <td>R$ {item.valor.toFixed(2)}</td>
                  <td>{item.caminhao}</td>
                  <td>{item.estadoConservacao}</td>
                  <td>{item.situacao}</td>
                  <td>
                    <div className="actions">
                      <button className="action-button edit" onClick={() => handleEditar(item.id)} title="Editar">
                        <Edit size={16} />
                      </button>
                      <button className="action-button view" onClick={() => handleDetalhes(item.id)} title="Detalhes">
                        <Eye size={16} />
                      </button>
                      <button className="action-button delete" onClick={() => handleExcluir(item.id)} title="Excluir">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={9} className="text-center">
                  Nenhum têxtil encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Texteis
