import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"

function CadastroTextil() {
  const [descricao, setDescricao] = useState("")
  const [dataCadastro, setDataCadastro] = useState("")
  const [quantidade, setQuantidade] = useState<number>(1)
  const [valor, setValor] = useState<number>(0)
  const [caminhao, setCaminhao] = useState("")
  const [categoria] = useState("Têxteis") // fixo
  const [estadoConservacao, setEstadoConservacao] = useState("")
  const [situacao, setSituacao] = useState("")
  const [anexo, setAnexo] = useState<File | null>(null)

  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    
    alert("Têxtil cadastrado com sucesso!")
    navigate("/categorias/textil")
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setAnexo(e.target.files[0])
    }
  }

  const handleCancel = () => {
    navigate("/categorias/textil")
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-primary mb-6">Cadastrar Têxtil</h1>

      <div className="form-container">
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="grid grid-cols-2 gap-4">
            <div className="form-group">
              <label className="form-label">Descrição</label>
              <input
                type="text"
                className="form-input"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Data de Cadastro</label>
              <input
                type="date"
                className="form-input"
                value={dataCadastro}
                onChange={(e) => setDataCadastro(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Quantidade</label>
              <input
                type="number"
                className="form-input"
                value={quantidade}
                onChange={(e) => setQuantidade(Number(e.target.value))}
                min="1"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Valor (R$)</label>
              <input
                type="number"
                step="0.01"
                className="form-input"
                value={valor}
                onChange={(e) => setValor(Number(e.target.value))}
                min="0"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Caminhão</label>
              <input
                type="text"
                className="form-input"
                value={caminhao}
                onChange={(e) => setCaminhao(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Categoria</label>
              <input type="text" className="form-input" value={categoria} disabled />
            </div>

            <div className="form-group">
              <label className="form-label">Estado de Conservação</label>
              <select
                className="form-select"
                value={estadoConservacao}
                onChange={(e) => setEstadoConservacao(e.target.value)}
                required
              >
                <option value="">Selecione</option>
                <option value="Novo">Novo</option>
                <option value="Seminovo">Seminovo</option>
                <option value="Usado em bom estado">Usado em bom estado</option>
                <option value="Usado com marcas de uso">Usado com marcas de uso</option>
                <option value="Precisa de reparos">Precisa de reparos</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Situação</label>
              <select className="form-select" value={situacao} onChange={(e) => setSituacao(e.target.value)} required>
                <option value="">Selecione</option>
                <option value="Disponível">Disponível</option>
                <option value="Reservado">Reservado</option>
                <option value="Vendido">Vendido</option>
                <option value="Doado">Doado</option>
              </select>
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Anexo (Foto)</label>
              <input type="file" className="form-input" onChange={handleFileChange} accept="image/*" />
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <button type="button" className="form-button secondary" onClick={handleCancel}>
              Cancelar
            </button>
            <button type="submit" className="form-button success">
              Cadastrar
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CadastroTextil
