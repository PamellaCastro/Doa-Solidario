import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getItemById, updateItem, Item } from "../../../services/ItemService";

const EditarEletrodomestico: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [item, setItem] = useState<Item | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchItem() {
      if (id) {
        try {
          const data = await getItemById(Number(id));
          setItem(data);
          setError(null);
        } catch (err) {
          console.error("Erro ao buscar item:", err);
          setError("Erro ao buscar item. Tente novamente mais tarde.");
        }
      }
    }
    fetchItem();
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!item) return;
    try {
      await updateItem(Number(id), item);
      alert("Item atualizado com sucesso!");
      navigate("/categorias/eletrodomesticos");
    } catch (err) {
      console.error("Erro ao atualizar item:", err);
      setError("Erro ao atualizar o item. Tente novamente mais tarde.");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    // Atualiza somente o campo "descricao", mantendo os demais campos inalterados
    setItem((prevItem) => prevItem ? { ...prevItem, descricao: value } : null);
  };

  if (error) {
    return <p className="error">{error}</p>;
  }

  if (!item) {
    return <p>Carregando...</p>;
  }

  return (
    <div>
      <h1>Editar Eletrodoméstico</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Descrição"
          value={item.descricao}
          onChange={handleChange}
          required
        />
        <button type="submit">Salvar Alterações</button>
      </form>
    </div>
  );
};

export default EditarEletrodomestico;
